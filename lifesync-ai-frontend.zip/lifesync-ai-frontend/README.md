# LifeSync AI — Frontend

React + TypeScript + Vite implementation of the **Main Intelligent Dashboard** Figma frame.
Plain CSS with design tokens (no Tailwind, no UI library), so it is easy to drop into any backend stack.

## Run locally

```bash
npm install
cp .env.example .env      # already provided as .env
npm run dev               # http://localhost:5173
```

## Build for deployment

```bash
npm run build             # outputs static files to ./dist
npm run preview           # test the production build locally
```

`dist/` is a static bundle — serve it from Nginx, S3/CloudFront, Netlify, Vercel, Firebase Hosting, or
have your backend serve it as static files. Configure SPA fallback (all routes → `index.html`).

## Connecting your backend

All network access lives in **`src/api/client.ts`**. It runs on mock data until you set:

```
VITE_USE_MOCKS=false
VITE_API_BASE_URL=/api            # or https://api.yourdomain.com
```

In development, Vite proxies `/api/*` to `VITE_DEV_PROXY_TARGET` (default `http://localhost:8000`).

### Endpoints the UI expects

| Method | Path                            | Body              | Returns                     |
|--------|---------------------------------|-------------------|-----------------------------|
| GET    | `/dashboard`                    | —                 | `DashboardData`             |
| POST   | `/obligations/:id/pay`          | —                 | `{ ok, message }`           |
| POST   | `/obligations/:id/snooze`       | `{ days }`        | `{ ok, message }`           |
| POST   | `/obligations/:id/delegate`     | `{ delegate }`    | `{ ok, message }`           |
| POST   | `/admin-items/:id/action`       | —                 | `{ ok, message }`           |
| POST   | `/insights/:id/apply`           | —                 | `{ ok, message }`           |
| GET    | `/search?q=`                    | —                 | `{ results: [...] }`        |

The exact JSON shape of `DashboardData` is defined in **`src/data/types.ts`** — mirror it in your backend
schema (Pydantic / Zod / DTOs) and the dashboard renders without further changes.

Auth: requests send cookies (`credentials: "include"`). For bearer tokens, uncomment the
`Authorization` header in `request()`.

## Project structure

```
src/
  api/client.ts         API seam + mocks
  components/           Sidebar, Header, Greeting, PriorityCard, CriticalAdmin,
                        Upcoming, LoadChart, Insights, Toasts, Icon
  data/types.ts         Backend contract (TypeScript types)
  data/mock.ts          Mock data + sidebar navigation
  hooks/useDashboard.ts Data loading + action state
  styles/tokens.css     Colors, type, radii, shadows (from Figma)
  styles/app.css        Component + responsive styles
```

## Placeholders to wire up

- Sidebar navigation only highlights the active item — plug in `react-router` when other screens exist.
- "Ask LifeSync AI", "Quick Add", and "Inspect Relationship Graph" log a `[TODO]` to the console.
- The avatar shows initials; set `user.avatarUrl` from your API to show a photo.
- Fonts (Inter, Plus Jakarta Sans) load from Google Fonts in `index.html`; self-host them if needed.
